#ifndef GUI_CONSOLE_H
#define GUI_CONSOLE_H

#ifdef _DEBUG
void redirect_io_to_console();
#endif

#endif // GUI_CONSOLE_H